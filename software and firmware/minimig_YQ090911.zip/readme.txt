
Changes and new features of YQ090911 release:

ARM firmware supports:

- MMC/SD/SDHC cards
- FAT16/FAT32 filesystems
- subfolders (unlimited number of entries and depth)
- Long File Names
- alphabetical sorting of entries
- selection of files and subfolders with a keypress
- scrolling of entries with PgUp/PgDn/Home keys
- selection of parent directory with Backspace key
- up to 4 virtual floppy drives
- up to 2 hard files emulating A600/A1200 hard disk controller (up to 4095 MB each)
- optional higher memory card transfer speed (requires simple hardware modification - highly recommended)
- firmware upgrades directly from the memory card

New FPGA features:

- improved system timing (blitter, CIAs, ROM)
- minor compatibility improvements (CIA access, INTREQ)
- support for two virtual hard disks
- implemented alliasing of custom register space (Kickstart 1.2 now works)

Upgrade procedure:

- copy FIRMWARE.UPG file to your memory card (which must contain valid minimig1.bin and kickstart file) 
- select from the OSD menu: firmware->update and confirm selection (your Minimig will restart and will complain about incorrect firmware version)
- now copy new minimig1.bin file to your memory card